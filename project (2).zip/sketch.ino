 
#include <Wire.h>
#include <Keypad.h>
#include <LiquidCrystal_I2C.h>

// LCD configuration
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Keypad configuration
const byte ROWS = 4;
const byte COLS = 4;

char keys[ROWS][COLS] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

byte rowPins[ROWS] = {9, 8, 7, 6};
byte colPins[COLS] = {5, 4, 3, 2};

Keypad keypad = Keypad(
  makeKeymap(keys),
  rowPins,
  colPins,
  ROWS,
  COLS
);

// Password settings
const char password[] = "1234";
char enteredPassword[5];
byte digitCount = 0;

void showPrompt() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Enter Password:");
  lcd.setCursor(0, 1);
}

void clearPassword() {
  digitCount = 0;
  enteredPassword[0] = '\0';
}

void setup() {
  lcd.init();
  lcd.backlight();

  clearPassword();
  showPrompt();
}

void loop() {
  char key = keypad.getKey();

  if (key == NO_KEY) {
    return;
  }

  // Clear password using *
  if (key == '*') {
    clearPassword();
    showPrompt();
    return;
  }

  // Submit password using #
  if (key == '#') {
    lcd.clear();

    if (digitCount == 4 &&
        strcmp(enteredPassword, password) == 0) {
      lcd.setCursor(0, 0);
      lcd.print("Access Granted");
      lcd.setCursor(0, 1);
      lcd.print("Lock Unlocked");
    } else {
      lcd.setCursor(0, 0);
      lcd.print("Wrong Password");
      lcd.setCursor(0, 1);
      lcd.print("Access Denied");
    }

    delay(2000);

    clearPassword();
    showPrompt();
    return;
  }

  // Accept only numeric digits
  if (key >= '0' && key <= '9' &&
      digitCount < 4) {
    enteredPassword[digitCount] = key;
    digitCount++;
    enteredPassword[digitCount] = '\0';

    lcd.setCursor(0, 1);
    lcd.print("                ");
    lcd.setCursor(0, 1);

    // Hide password digits
    for (byte i = 0; i < digitCount; i++) {
      lcd.print('*');
    }
  }
}
